<html>
    <body>
        Welcome <?php echo $_POST["name"]; ?><br />
        Your email is <?php echo $_POST["email"]; ?>
    </body>
</html>